"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight, X, ZoomIn } from "lucide-react"

interface OutfitImageGalleryProps {
  images: string[]
  onRemoveImage?: (index: number) => void
  editable?: boolean
}

export function OutfitImageGallery({ images, onRemoveImage, editable = false }: OutfitImageGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [showFullscreen, setShowFullscreen] = useState(false)

  // If no images, show placeholder
  if (images.length === 0) {
    return (
      <div className="aspect-video bg-secondary/20 rounded-md flex items-center justify-center">
        <p className="text-muted-foreground text-sm">No images available</p>
      </div>
    )
  }

  const nextImage = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length)
  }

  const prevImage = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length)
  }

  return (
    <div className="relative">
      <div className="aspect-video bg-secondary/20 rounded-md overflow-hidden relative">
        <img
          src={images[currentIndex] || "/placeholder.svg"}
          alt={`Outfit image ${currentIndex + 1}`}
          className="w-full h-full object-cover"
          onError={(e) => {
            // If image fails to load, replace with placeholder
            ;(e.target as HTMLImageElement).src = `https://placeholder.svg?height=300&width=500&text=Image+Error`
          }}
        />

        {/* Image counter */}
        <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full">
          {currentIndex + 1} / {images.length}
        </div>

        {/* Fullscreen button */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-black/40 hover:bg-black/60 text-white h-8 w-8"
          onClick={() => setShowFullscreen(true)}
        >
          <ZoomIn size={16} />
        </Button>

        {/* Remove button (only if editable) */}
        {editable && onRemoveImage && (
          <Button
            variant="destructive"
            size="icon"
            className="absolute top-2 left-2 h-8 w-8"
            onClick={() => onRemoveImage(currentIndex)}
          >
            <X size={16} />
          </Button>
        )}
      </div>

      {/* Navigation buttons (only show if more than one image) */}
      {images.length > 1 && (
        <>
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white h-8 w-8"
            onClick={prevImage}
          >
            <ChevronLeft size={16} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white h-8 w-8"
            onClick={nextImage}
          >
            <ChevronRight size={16} />
          </Button>
        </>
      )}

      {/* Fullscreen dialog */}
      <Dialog open={showFullscreen} onOpenChange={setShowFullscreen}>
        <DialogContent className="max-w-4xl w-[90vw]">
          <DialogHeader>
            <DialogTitle>Outfit Image {currentIndex + 1}</DialogTitle>
          </DialogHeader>
          <div className="relative">
            <img
              src={images[currentIndex] || "/placeholder.svg"}
              alt={`Outfit image ${currentIndex + 1} fullscreen`}
              className="w-full object-contain max-h-[70vh]"
            />
            {images.length > 1 && (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white"
                  onClick={() => {
                    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length)
                  }}
                >
                  <ChevronLeft size={20} />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white"
                  onClick={() => {
                    setCurrentIndex((prev) => (prev + 1) % images.length)
                  }}
                >
                  <ChevronRight size={20} />
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
