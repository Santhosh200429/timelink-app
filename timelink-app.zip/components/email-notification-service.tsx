"use client"

import { useEffect, useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface EmailServiceProps {
  userEmail: string
  outfitId: number
  outfitName: string
  imageUrl: string
  appUrl?: string
}

export function sendEmailNotification({
  userEmail,
  outfitId,
  outfitName,
  imageUrl,
  appUrl = window.location.origin,
}: EmailServiceProps): Promise<boolean> {
  // In a real app, we would use a service like EmailJS, SendGrid, or a custom API
  // For this demo, we'll simulate sending an email
  return new Promise((resolve) => {
    console.log("Sending email notification to:", userEmail)
    console.log("Email content:", {
      subject: `New image added to your outfit: ${outfitName}`,
      body: `
        Hello,
        
        A new image has been added to your outfit "${outfitName}".
        
        View your updated outfit here: ${appUrl}/wardrobe?outfit=${outfitId}
        
        Image preview: ${imageUrl}
        
        Thanks for using Timelink!
      `,
    })

    // Simulate network delay
    setTimeout(() => {
      // Simulate 90% success rate
      const success = Math.random() < 0.9
      resolve(success)
    }, 1500)
  })
}

export function useEmailNotification() {
  const { toast } = useToast()
  const [pendingNotifications, setPendingNotifications] = useState<EmailServiceProps[]>([])
  const [isSending, setIsSending] = useState(false)

  // Process the notification queue
  useEffect(() => {
    const processQueue = async () => {
      if (pendingNotifications.length === 0 || isSending) return

      setIsSending(true)
      const notification = pendingNotifications[0]

      try {
        const success = await sendEmailNotification(notification)

        if (success) {
          toast({
            title: "Email notification sent",
            description: `Notification about "${notification.outfitName}" sent to ${notification.userEmail}`,
          })
        } else {
          toast({
            title: "Failed to send email",
            description: "The notification could not be sent. It will be retried automatically.",
            variant: "destructive",
          })
          // Put it back in the queue to retry
          setPendingNotifications((prev) => [...prev.slice(1), notification])
          setIsSending(false)
          return
        }
      } catch (error) {
        console.error("Error sending email notification:", error)
        toast({
          title: "Error sending email",
          description: "An unexpected error occurred. The notification will be retried.",
          variant: "destructive",
        })
        // Put it back in the queue to retry
        setPendingNotifications((prev) => [...prev.slice(1), notification])
        setIsSending(false)
        return
      }

      // Remove the processed notification from the queue
      setPendingNotifications((prev) => prev.slice(1))
      setIsSending(false)
    }

    processQueue()
  }, [pendingNotifications, isSending, toast])

  const queueEmailNotification = (notification: EmailServiceProps) => {
    setPendingNotifications((prev) => [...prev, notification])
  }

  return {
    queueEmailNotification,
    pendingCount: pendingNotifications.length,
    isSending,
  }
}
