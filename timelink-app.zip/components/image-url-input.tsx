"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, Plus, X } from "lucide-react"

interface ImageUrlInputProps {
  onAddImage: (url: string) => void
  buttonText?: string
}

export function ImageUrlInput({ onAddImage, buttonText = "Add Image" }: ImageUrlInputProps) {
  const [imageUrl, setImageUrl] = useState("")
  const [isPreviewLoading, setIsPreviewLoading] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [previewError, setPreviewError] = useState<string | null>(null)

  const handlePreview = () => {
    if (!imageUrl.trim()) return

    setIsPreviewLoading(true)
    setPreviewError(null)

    // Create an image element to test loading
    const img = new Image()
    img.onload = () => {
      setPreviewUrl(imageUrl)
      setIsPreviewLoading(false)
    }
    img.onerror = () => {
      setPreviewError("Failed to load image. Please check the URL and try again.")
      setPreviewUrl(null)
      setIsPreviewLoading(false)
    }
    img.src = imageUrl
  }

  const handleAddImage = () => {
    if (previewUrl) {
      onAddImage(previewUrl)
      setImageUrl("")
      setPreviewUrl(null)
    }
  }

  const cancelPreview = () => {
    setPreviewUrl(null)
    setPreviewError(null)
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="image-url">Image URL</Label>
        <div className="flex gap-2">
          <Input
            id="image-url"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="https://example.com/image.jpg"
            className="flex-1"
          />
          <Button
            type="button"
            variant="outline"
            onClick={handlePreview}
            disabled={!imageUrl.trim() || isPreviewLoading}
          >
            {isPreviewLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Preview"}
          </Button>
        </div>
      </div>

      {previewError && <div className="p-3 bg-destructive/10 text-destructive rounded-md text-sm">{previewError}</div>}

      {previewUrl && (
        <div className="space-y-2">
          <div className="relative">
            <img
              src={previewUrl || "/placeholder.svg"}
              alt="Preview"
              className="w-full h-auto max-h-[200px] object-contain border rounded-md"
            />
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute top-2 right-2 h-8 w-8"
              onClick={cancelPreview}
            >
              <X size={16} />
            </Button>
          </div>
          <Button type="button" onClick={handleAddImage} className="w-full">
            <Plus size={16} className="mr-2" /> {buttonText}
          </Button>
        </div>
      )}
    </div>
  )
}
