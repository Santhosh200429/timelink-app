"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

// Define types for our state
type Location = {
  lat: number
  lng: number
  address: string
} | null

// Update the Event type to include recurring information and auto-deletion settings
type Event = {
  id: number
  title: string
  date: Date
  startTime: string
  endTime: string
  location: string
  description: string
  category: string
  mapLocation?: Location
  // New fields for recurring events and auto-deletion
  isRecurring: boolean
  recurrencePattern?: "daily" | "weekly" | "monthly" | "yearly"
  recurrenceInterval?: number // e.g., every 2 weeks
  recurrenceDay?: number[] // days of week for weekly (0-6, Sunday-Saturday)
  recurrenceEndDate?: Date | null // null means no end date
  skipAutoDelete: boolean // if true, event won't be auto-deleted
  lastOccurrence?: Date // for tracking the last occurrence of a recurring event
}

// Update Holiday type to use icon instead of color
type Holiday = {
  id: number
  name: string
  startDate: Date
  endDate: Date
  icon: string // Icon name from holiday-icons.ts
  description?: string
}

// Updated Task type to include completedDate
type Task = {
  id: number
  title: string
  completed: boolean
  completedDate?: Date // When the task was last completed
  locked?: boolean // Whether the task is locked (can't be unticked)
}

type Routine = {
  id: number
  title: string
  icon: string
  streak: number
  frequency: string
  goal: string
  goalPeriod: number
  goalUnit: "days" | "weeks" | "months"
  description: string
  tasks: Task[]
  progress: number
  lastResetDate?: Date // Track when tasks were last reset
  lastStreakUpdate?: Date // Track when streak was last updated
}

type WardrobeColor = {
  name: string
  hex: string
}

type WardrobeItem = {
  id: number
  name: string
  brand: string
  tags: string[]
  colors: WardrobeColor[]
  status: "clean" | "worn"
  imageUrl: string
}

type WardrobeCategory = {
  id: string
  label: string
}

type WardrobeItems = {
  [key: string]: WardrobeItem[]
}

// Updated Outfit type to include images array
type Outfit = {
  id: number
  name: string
  items: number[] // Array of item IDs
  occasion: string
  weather: string
  rating: number // -1 for disliked, 0 for neutral, 1 for liked
  userCreated: boolean
  images: string[] // Array of image URLs
  description?: string // Optional description for the outfit
}

// Update the UserSettings type to replace location with weatherCondition
type UserSettings = {
  profile: {
    name: string
    email: string
    avatar: string | null
  }
  notifications: {
    routineReminders: boolean
    calendarAlerts: boolean
    emailNotifications: boolean
    emailAddress: string
    outfitImageNotifications: boolean // New setting for outfit image notifications
  }
  appearance: {
    darkMode: boolean
    theme: string
    fontSize: "small" | "medium" | "large"
  }
  weatherCondition: "sunny" | "cloudy" | "rainy" | "snowy" | "windy"
  calendar?: {
    view: "day" | "week" | "month" | "year"
  }
}

// Define the context type
type AppStateContextType = {
  // Calendar state
  events: Event[]
  setEvents: React.Dispatch<React.SetStateAction<Event[]>>

  // Holidays state
  holidays: Holiday[]
  setHolidays: React.Dispatch<React.SetStateAction<Holiday[]>>

  // Routines state
  routines: Routine[]
  setRoutines: React.Dispatch<React.SetStateAction<Routine[]>>
  checkAndResetRoutines: () => void // Function to check and reset routines

  // Wardrobe state
  wardrobeCategories: WardrobeCategory[]
  setWardrobeCategories: React.Dispatch<React.SetStateAction<WardrobeCategory[]>>
  wardrobeItems: WardrobeItems
  setWardrobeItems: React.Dispatch<React.SetStateAction<WardrobeItems>>
  outfits: Outfit[]
  setOutfits: React.Dispatch<React.SetStateAction<Outfit[]>>

  // Settings
  userSettings: UserSettings
  setUserSettings: React.Dispatch<React.SetStateAction<UserSettings>>

  // Available colors for wardrobe items
  availableColors: WardrobeColor[]

  // Available icons for routines
  availableIcons: string[]

  // API Key for AI assistant
  apiKey: string
  setApiKey: React.Dispatch<React.SetStateAction<string>>
}

// Create the context
const AppStateContext = createContext<AppStateContextType | undefined>(undefined)

// Create a provider component
export function AppStateProvider({ children }: { children: React.ReactNode }) {
  // Available colors for wardrobe items
  const availableColors: WardrobeColor[] = [
    { name: "Black", hex: "#000000" },
    { name: "White", hex: "#FFFFFF" },
    { name: "Gray", hex: "#808080" },
    { name: "Navy", hex: "#000080" },
    { name: "Blue", hex: "#0000FF" },
    { name: "Light Blue", hex: "#ADD8E6" },
    { name: "Red", hex: "#FF0000" },
    { name: "Burgundy", hex: "#800020" },
    { name: "Pink", hex: "#FFC0CB" },
    { name: "Purple", hex: "#800080" },
    { name: "Green", hex: "#008000" },
    { name: "Olive", hex: "#808000" },
    { name: "Yellow", hex: "#FFFF00" },
    { name: "Orange", hex: "#FFA500" },
    { name: "Brown", hex: "#A52A2A" },
    { name: "Beige", hex: "#F5F5DC" },
    { name: "Khaki", hex: "#C3B091" },
    { name: "Teal", hex: "#008080" },
  ]

  // Available icons for routines
  const availableIcons: string[] = [
    "Coffee",
    "BookOpen",
    "Dumbbell",
    "Moon",
    "Sun",
    "Heart",
    "Bike",
    "Utensils",
    "Brain",
    "Briefcase",
    "Code",
    "Music",
    "Palette",
    "Pencil",
    "Phone",
    "Camera",
    "Car",
    "Plane",
    "Train",
    "Ship",
    "Home",
    "Building",
    "Tree",
    "Umbrella",
    "Cloud",
    "Droplet",
    "Wind",
    "Snowflake",
    "Thermometer",
    "Zap",
    "Activity",
    "AlertCircle",
    "Award",
    "Battery",
    "Bell",
    "Calendar",
    "Clock",
    "Compass",
    "Database",
    "Download",
    "Eye",
    "Film",
    "Flag",
    "Folder",
    "Gift",
    "Globe",
    "Headphones",
    "Key",
    "Layers",
    "Map",
    "Monitor",
    "Package",
    "Paperclip",
    "Printer",
  ]

  const [events, setEvents] = useState<Event[]>([
    {
      id: 1,
      title: "Team Meeting",
      date: new Date(2025, 3, 11), // April 11, 2025
      startTime: "10:00",
      endTime: "11:00",
      location: "Conference Room A",
      description: "Weekly sync with product team",
      category: "Work",
      isRecurring: false,
      skipAutoDelete: false,
    },
    {
      id: 2,
      title: "Lunch with Sarah",
      date: new Date(2025, 3, 11), // April 11, 2025
      startTime: "13:30",
      endTime: "14:30",
      location: "Cafe Milano",
      description: "Catch up over lunch",
      category: "Personal",
      isRecurring: false,
      skipAutoDelete: false,
    },
    {
      id: 3,
      title: "Gym Session",
      date: new Date(2025, 3, 11), // April 11, 2025
      startTime: "17:00",
      endTime: "18:00",
      location: "Fitness Center",
      description: "Cardio + upper body",
      category: "Health",
      isRecurring: false,
      skipAutoDelete: false,
    },
    {
      id: 4,
      title: "Doctor Appointment",
      date: new Date(2025, 3, 15), // April 15, 2025
      startTime: "09:00",
      endTime: "10:00",
      location: "Medical Center",
      description: "Annual checkup",
      category: "Health",
      isRecurring: false,
      skipAutoDelete: false,
    },
    {
      id: 5,
      title: "Birthday Party",
      date: new Date(2025, 3, 18), // April 18, 2025
      startTime: "19:00",
      endTime: "22:00",
      location: "John's Place",
      description: "John's 30th birthday celebration",
      category: "Social",
      isRecurring: false,
      skipAutoDelete: false,
    },
  ])

  // Initialize holidays with icons
  const [holidays, setHolidays] = useState<Holiday[]>([
    {
      id: 1,
      name: "New Year's Day",
      startDate: new Date(2025, 0, 1),
      endDate: new Date(2025, 0, 1),
      icon: "Firework",
      description: "New Year's Day celebration",
    },
    {
      id: 2,
      name: "Spring Break",
      startDate: new Date(2025, 2, 15),
      endDate: new Date(2025, 2, 22),
      icon: "Beach Umbrella",
      description: "Spring break vacation",
    },
    {
      id: 3,
      name: "Memorial Day Weekend",
      startDate: new Date(2025, 4, 24),
      endDate: new Date(2025, 4, 26),
      icon: "Flag",
      description: "Memorial Day long weekend",
    },
    {
      id: 4,
      name: "Christmas",
      startDate: new Date(2025, 11, 25),
      endDate: new Date(2025, 11, 25),
      icon: "Christmas Tree",
      description: "Christmas Day",
    },
    {
      id: 5,
      name: "Summer Vacation",
      startDate: new Date(2025, 6, 15),
      endDate: new Date(2025, 7, 5),
      icon: "Beach Vacation",
      description: "Summer family vacation",
    },
  ])

  const [routines, setRoutines] = useState<Routine[]>([
    {
      id: 1,
      title: "Morning Routine",
      icon: "Coffee",
      streak: 0,
      frequency: "daily",
      goal: "Start the day with energy and mindfulness",
      goalPeriod: 30,
      goalUnit: "days",
      description: "A morning routine to energize and prepare for the day",
      tasks: [
        { id: 1, title: "Drink water", completed: false, locked: false },
        { id: 2, title: "Meditate for 10 minutes", completed: false, locked: false },
        { id: 3, title: "Stretch", completed: false, locked: false },
      ],
      progress: 0,
      lastResetDate: new Date(),
    },
    {
      id: 2,
      title: "Reading",
      icon: "BookOpen",
      streak: 0,
      frequency: "daily",
      goal: "Read 12 books this year",
      goalPeriod: 90,
      goalUnit: "days",
      description: "Daily reading habit to expand knowledge and relax",
      tasks: [{ id: 1, title: "Read for 30 minutes", completed: false, locked: false }],
      progress: 0,
      lastResetDate: new Date(),
    },
    {
      id: 3,
      title: "Workout",
      icon: "Dumbbell",
      streak: 0,
      frequency: "weekly",
      goal: "Build strength and improve cardiovascular health",
      goalPeriod: 12,
      goalUnit: "weeks",
      description: "Weekly workout routine for strength and cardio",
      tasks: [
        { id: 1, title: "Cardio", completed: false, locked: false },
        { id: 2, title: "Strength training", completed: false, locked: false },
        { id: 3, title: "Stretching", completed: false, locked: false },
      ],
      progress: 0,
      lastResetDate: new Date(),
    },
    {
      id: 4,
      title: "Evening Routine",
      icon: "Moon",
      streak: 0,
      frequency: "daily",
      goal: "Wind down properly for better sleep",
      goalPeriod: 30,
      goalUnit: "days",
      description: "Evening routine to improve sleep quality",
      tasks: [
        { id: 1, title: "Journal", completed: false, locked: false },
        { id: 2, title: "Plan tomorrow", completed: false, locked: false },
        { id: 3, title: "No screens 1hr before bed", completed: false, locked: false },
      ],
      progress: 0,
      lastResetDate: new Date(),
    },
  ])

  const [wardrobeCategories, setWardrobeCategories] = useState<WardrobeCategory[]>([
    { id: "shirts", label: "Shirts" },
    { id: "pants", label: "Pants" },
    { id: "shoes", label: "Shoes" },
    { id: "outerwear", label: "Outerwear" },
    { id: "accessories", label: "Accessories" },
    { id: "shorts", label: "Shorts" },
    { id: "dresses", label: "Dresses" },
    { id: "skirts", label: "Skirts" },
  ])

  const [wardrobeItems, setWardrobeItems] = useState<WardrobeItems>({
    shirts: [
      {
        id: 1,
        name: "Striped Cotton Shirt",
        brand: "H&M",
        tags: ["casual", "summer"],
        colors: [
          { name: "Blue", hex: "#0000FF" },
          { name: "White", hex: "#FFFFFF" },
        ],
        status: "clean",
        imageUrl:
          "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=640&h=800&q=80",
      },
      {
        id: 2,
        name: "Casual Linen Shirt",
        brand: "Zara",
        tags: ["casual", "summer"],
        colors: [{ name: "Beige", hex: "#F5F5DC" }],
        status: "worn",
        imageUrl:
          "https://images.unsplash.com/photo-1618354691373-49944c15aa3b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=640&h=800&q=80",
      },
    ],
    pants: [
      {
        id: 3,
        name: "Classic Blue Jeans",
        brand: "Levi's",
        tags: ["casual", "everyday"],
        colors: [{ name: "Blue", hex: "#0000FF" }],
        status: "clean",
        imageUrl:
          "https://images.unsplash.com/photo-1591047139829-d91aecb6ca99?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=640&h=800&q=80",
      },
      {
        id: 4,
        name: "Slim Fit Chinos",
        brand: "Uniqlo",
        tags: ["casual", "work"],
        colors: [{ name: "Khaki", hex: "#C3B091" }],
        status: "clean",
        imageUrl:
          "https://images.unsplash.com/photo-1602810318383-e386cc12b888?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=640&h=800&q=80",
      },
    ],
    shoes: [
      {
        id: 5,
        name: "Leather Sneakers",
        brand: "Adidas",
        tags: ["casual", "everyday"],
        colors: [{ name: "White", hex: "#FFFFFF" }],
        status: "worn",
        imageUrl:
          "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=640&h=800&q=80",
      },
      {
        id: 6,
        name: "Suede Loafers",
        brand: "Clarks",
        tags: ["formal", "work"],
        colors: [{ name: "Brown", hex: "#A52A2A" }],
        status: "clean",
        imageUrl:
          "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=640&h=800&q=80",
      },
    ],
    outerwear: [
      {
        id: 7,
        name: "Light Jacket",
        brand: "North Face",
        tags: ["casual", "spring"],
        colors: [{ name: "Gray", hex: "#808080" }],
        status: "clean",
        imageUrl:
          "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=640&h=800&q=80",
      },
    ],
    accessories: [
      {
        id: 8,
        name: "Watch",
        brand: "Timex",
        tags: ["everyday", "accessory"],
        colors: [
          { name: "Silver", hex: "#C0C0C0" },
          { name: "Black", hex: "#000000" },
        ],
        status: "clean",
        imageUrl:
          "https://images.unsplash.com/photo-1524805444758-089113d48a6d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=640&h=800&q=80",
      },
    ],
    shorts: [],
    dresses: [],
    skirts: [],
  })

  // Updated outfits with images array
  const [outfits, setOutfits] = useState<Outfit[]>([
    {
      id: 1,
      name: "Today's Casual",
      items: [7, 1, 3, 5], // Light Jacket, Striped Cotton Shirt, Classic Blue Jeans, Leather Sneakers
      occasion: "Everyday",
      weather: "Partly cloudy, 22°C",
      rating: 0,
      userCreated: false,
      images: [
        "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80",
      ],
      description: "A comfortable casual outfit for everyday wear",
    },
    {
      id: 2,
      name: "Work Meeting",
      items: [2, 4, 6, 8], // Casual Linen Shirt, Slim Fit Chinos, Suede Loafers, Watch
      occasion: "Work",
      weather: "Partly cloudy, 22°C",
      rating: 0,
      userCreated: false,
      images: [
        "https://images.unsplash.com/photo-1617137968427-85924c800a22?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1974&q=80",
      ],
      description: "Professional outfit suitable for business meetings",
    },
  ])

  // Update the initial state for userSettings with new outfitImageNotifications field
  const [userSettings, setUserSettings] = useState<UserSettings>({
    profile: {
      name: "Alex Johnson",
      email: "alex.johnson@example.com",
      avatar: null,
    },
    notifications: {
      routineReminders: true,
      calendarAlerts: true,
      emailNotifications: false,
      emailAddress: "alex.johnson@example.com",
      outfitImageNotifications: true, // New setting for outfit image notifications
    },
    appearance: {
      darkMode: true,
      theme: "default",
      fontSize: "medium",
    },
    weatherCondition: "sunny",
    calendar: {
      view: "month",
    },
  })

  // State for API key
  const [apiKey, setApiKey] = useState<string>("")

  // Function to check if a new period has started based on frequency
  const hasNewPeriodStarted = (lastResetDate: Date | undefined, frequency: string): boolean => {
    if (!lastResetDate) return true

    const now = new Date()
    const lastReset = new Date(lastResetDate)

    // Check if dates are the same day
    const isSameDay = (date1: Date, date2: Date) => {
      return (
        date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate()
      )
    }

    // Check if dates are in the same week
    const isSameWeek = (date1: Date, date2: Date) => {
      const getWeekNumber = (d: Date) => {
        const firstDayOfYear = new Date(d.getFullYear(), 0, 1)
        const pastDaysOfYear = (d.getTime() - firstDayOfYear.getTime()) / 86400000
        return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7)
      }
      return date1.getFullYear() === date2.getFullYear() && getWeekNumber(date1) === getWeekNumber(date2)
    }

    // Check if dates are in the same month
    const isSameMonth = (date1: Date, date2: Date) => {
      return date1.getFullYear() === date2.getFullYear() && date1.getMonth() === date2.getMonth()
    }

    if (frequency === "daily") {
      return !isSameDay(now, lastReset)
    } else if (frequency === "weekly") {
      return !isSameWeek(now, lastReset)
    } else if (frequency === "monthly") {
      return !isSameMonth(now, lastReset)
    }

    return false
  }

  // Function to check and reset routines based on their frequency
  const checkAndResetRoutines = () => {
    const updatedRoutines = routines.map((routine) => {
      // Check if a new period has started
      if (hasNewPeriodStarted(routine.lastResetDate, routine.frequency)) {
        // Check if all tasks were completed before resetting
        const allTasksCompleted = routine.tasks.every((task) => task.completed)

        // Update streak if all tasks were completed
        let newStreak = routine.streak
        if (allTasksCompleted) {
          newStreak += 1
        } else if (routine.lastResetDate) {
          // Reset streak if not all tasks were completed and this isn't the first time
          newStreak = 0
        }

        // Reset tasks and update dates
        return {
          ...routine,
          tasks: routine.tasks.map((task) => ({
            ...task,
            completed: false,
            completedDate: undefined,
            locked: false,
          })),
          progress: 0,
          streak: newStreak,
          lastResetDate: new Date(),
          lastStreakUpdate: allTasksCompleted ? new Date() : routine.lastStreakUpdate,
        }
      }
      return routine
    })

    setRoutines(updatedRoutines)
  }

  // Load state from localStorage on initial render
  useEffect(() => {
    try {
      // Load API key
      const savedApiKey = localStorage.getItem("openai_api_key")
      if (savedApiKey) {
        setApiKey(savedApiKey)
      }

      // Load events
      const savedEvents = localStorage.getItem("timelink_events")
      if (savedEvents) {
        const parsedEvents = JSON.parse(savedEvents)
        // Convert string dates back to Date objects
        const eventsWithDates = parsedEvents.map((event: any) => ({
          ...event,
          date: new Date(event.date),
          recurrenceEndDate: event.recurrenceEndDate ? new Date(event.recurrenceEndDate) : null,
          lastOccurrence: event.lastOccurrence ? new Date(event.lastOccurrence) : undefined,
        }))
        setEvents(eventsWithDates)
      }

      // Load holidays
      const savedHolidays = localStorage.getItem("timelink_holidays")
      if (savedHolidays) {
        const parsedHolidays = JSON.parse(savedHolidays)
        // Convert string dates back to Date objects
        const holidaysWithDates = parsedHolidays.map((holiday: any) => ({
          ...holiday,
          startDate: new Date(holiday.startDate),
          endDate: new Date(holiday.endDate),
        }))
        setHolidays(holidaysWithDates)
      }

      // Load routines
      const savedRoutines = localStorage.getItem("timelink_routines")
      if (savedRoutines) {
        const parsedRoutines = JSON.parse(savedRoutines)
        // Convert string dates back to Date objects
        const routinesWithDates = parsedRoutines.map((routine: any) => ({
          ...routine,
          lastResetDate: routine.lastResetDate ? new Date(routine.lastResetDate) : undefined,
          lastStreakUpdate: routine.lastStreakUpdate ? new Date(routine.lastStreakUpdate) : undefined,
          tasks: routine.tasks.map((task: any) => ({
            ...task,
            completedDate: task.completedDate ? new Date(task.completedDate) : undefined,
          })),
        }))
        setRoutines(routinesWithDates)
      }

      // Load wardrobe categories
      const savedCategories = localStorage.getItem("timelink_wardrobe_categories")
      if (savedCategories) {
        setWardrobeCategories(JSON.parse(savedCategories))
      }

      // Load wardrobe items
      const savedItems = localStorage.getItem("timelink_wardrobe_items")
      if (savedItems) {
        setWardrobeItems(JSON.parse(savedItems))
      }

      // Load outfits
      const savedOutfits = localStorage.getItem("timelink_outfits")
      if (savedOutfits) {
        const parsedOutfits = JSON.parse(savedOutfits)
        // Ensure all outfits have an images array
        const outfitsWithImages = parsedOutfits.map((outfit: any) => ({
          ...outfit,
          images: outfit.images || [],
        }))
        setOutfits(outfitsWithImages)
      }

      // Load user settings
      const savedSettings = localStorage.getItem("timelink_user_settings")
      if (savedSettings) {
        const parsedSettings = JSON.parse(savedSettings)
        // Ensure settings has outfitImageNotifications field
        setUserSettings({
          ...parsedSettings,
          notifications: {
            ...parsedSettings.notifications,
            outfitImageNotifications:
              parsedSettings.notifications.outfitImageNotifications !== undefined
                ? parsedSettings.notifications.outfitImageNotifications
                : true,
          },
        })
      }
    } catch (error) {
      console.error("Error loading state from localStorage:", error)
    }
  }, [])

  // Check and reset routines when the app loads
  useEffect(() => {
    checkAndResetRoutines()
    // Set up a daily check for routine resets
    const intervalId = setInterval(checkAndResetRoutines, 1000 * 60 * 60) // Check every hour
    return () => clearInterval(intervalId)
  }, [])

  // Save state to localStorage whenever it changes
  useEffect(() => {
    try {
      // Save API key
      if (apiKey) {
        localStorage.setItem("openai_api_key", apiKey)
      }

      // Save events
      localStorage.setItem("timelink_events", JSON.stringify(events))

      // Save holidays
      localStorage.setItem("timelink_holidays", JSON.stringify(holidays))

      // Save routines
      localStorage.setItem("timelink_routines", JSON.stringify(routines))

      // Save wardrobe categories
      localStorage.setItem("timelink_wardrobe_categories", JSON.stringify(wardrobeCategories))

      // Save wardrobe items
      localStorage.setItem("timelink_wardrobe_items", JSON.stringify(wardrobeItems))

      // Save outfits
      localStorage.setItem("timelink_outfits", JSON.stringify(outfits))

      // Save user settings
      localStorage.setItem("timelink_user_settings", JSON.stringify(userSettings))
    } catch (error) {
      console.error("Error saving state to localStorage:", error)
    }
  }, [events, holidays, routines, wardrobeCategories, wardrobeItems, outfits, userSettings, apiKey])

  // Create the context value
  const contextValue: AppStateContextType = {
    events,
    setEvents,
    holidays,
    setHolidays,
    routines,
    setRoutines,
    checkAndResetRoutines,
    wardrobeCategories,
    setWardrobeCategories,
    wardrobeItems,
    setWardrobeItems,
    outfits,
    setOutfits,
    userSettings,
    setUserSettings,
    availableColors,
    availableIcons,
    apiKey,
    setApiKey,
  }

  return <AppStateContext.Provider value={contextValue}>{children}</AppStateContext.Provider>
}

// Create a custom hook to use the context
export function useAppState() {
  const context = useContext(AppStateContext)
  if (context === undefined) {
    throw new Error("useAppState must be used within an AppStateProvider")
  }
  return context
}
